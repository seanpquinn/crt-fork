//////////////////////////////////////////////////////////
// Filename: bfield_ass_a.h
// Authors:  Michael Sutherland
//           Brian Baughman 
//
// Copyright 2007 __MyCompanyName__. All rights reserved.
//
// Description: This file contains the implementation of
//                the ASS_A spiral magnetic field
//
//////////////////////////////////////////////////////////

#ifndef _ASS_A_H
#define _ASS_A_H

#include "bfield_ssfield.h"
#include <string>

class ASS_A: public SSFIELD
{

 private:


 public:
  ASS_A():SSFIELD(-1,true) {

  };
  virtual ~ASS_A(){

  };

  
  std::string GetType(void) const
  {
    return "ass_a";
  };

};


#endif
